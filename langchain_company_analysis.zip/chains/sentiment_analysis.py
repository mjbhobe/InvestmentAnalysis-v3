import requests
from bs4 import BeautifulSoup
from textblob import TextBlob

def get_headlines(symbol):
    url = f"https://finance.yahoo.com/quote/{symbol}?p={symbol}"
    html = requests.get(url).text
    soup = BeautifulSoup(html, "html.parser")
    return [a.text for a in soup.find_all("a") if a.text and len(a.text) > 40][:5]

def run_sentiment_analysis(symbol):
    headlines = get_headlines(symbol)
    scores = [TextBlob(h).sentiment.polarity for h in headlines]
    avg = sum(scores) / len(scores) if scores else 0
    tone = "Positive" if avg > 0.1 else "Negative" if avg < -0.1 else "Neutral"
    return {"tone": tone, "score": round(avg, 3), "headlines": headlines}