def analyze_financials(data):
    fin = data.get("financials", {})
    bs = data.get("balance_sheet", {})
    cf = data.get("cashflow", {})

    try:
        revenue_growth = ((fin.loc["Total Revenue"][0] - fin.loc["Total Revenue"][1]) / fin.loc["Total Revenue"][1]) * 100
        net_margin = (fin.loc["Net Income"][0] / fin.loc["Total Revenue"][0]) * 100
        roe = (fin.loc["Net Income"][0] / bs.loc["Total Stockholder Equity"][0]) * 100
        fcf = cf.loc["Total Cash From Operating Activities"][0] - cf.loc["Capital Expenditures"][0]
        debt_equity = bs.loc["Total Liab"][0] / bs.loc["Total Stockholder Equity"][0]

        return {
            "Revenue Growth": f"{revenue_growth:.2f}%",
            "Net Margin": f"{net_margin:.2f}%",
            "ROE": f"{roe:.2f}%",
            "Free Cash Flow": f"{fcf/1e9:.2f} B",
            "Debt to Equity": f"{debt_equity:.2f}"
        }
    except:
        return {"error": "Incomplete or missing data"}