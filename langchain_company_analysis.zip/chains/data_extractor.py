import yfinance as yf
from sec_edgar_downloader import Downloader
import os

def extract_data(symbol: str):
    ticker = yf.Ticker(symbol)
    data = {
        "yf_data": {
            "financials": ticker.financials,
            "balance_sheet": ticker.balance_sheet,
            "cashflow": ticker.cashflow
        }
    }

    dl = Downloader()
    dl.get("10-K", symbol, amount=1)
    folder = f"sec-edgar-filings/{symbol}/10-K"
    summary = "10-K not found"
    for root, _, files in os.walk(folder):
        for file in files:
            if file.endswith(".txt"):
                with open(os.path.join(root, file), "r", encoding="utf-8", errors="ignore") as f:
                    summary = f.read()[:1000]
    data["10k_summary"] = summary
    return data