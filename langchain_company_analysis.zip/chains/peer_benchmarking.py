import yfinance as yf

def get_peers(symbol):
    target_sector = yf.Ticker(symbol).info.get("sector")
    all_symbols = ["AAPL", "MSFT", "GOOGL", "AMZN", "META", "TSLA", "NVDA", "CSCO", "CRM", "INTC"]
    return [s for s in all_symbols if yf.Ticker(s).info.get("sector") == target_sector and s != symbol][:5]

def benchmark_peers(symbol):
    peers = get_peers(symbol)
    results = {}
    for sym in peers:
        try:
            t = yf.Ticker(sym)
            fin = t.financials
            bs = t.balance_sheet
            margin = (fin.loc["Net Income"][0] / fin.loc["Total Revenue"][0]) * 100
            roe = (fin.loc["Net Income"][0] / bs.loc["Total Stockholder Equity"][0]) * 100
            results[sym] = {"Net Margin": f"{margin:.2f}%", "ROE": f"{roe:.2f}%"}
        except:
            results[sym] = {"error": "Data error"}
    return results