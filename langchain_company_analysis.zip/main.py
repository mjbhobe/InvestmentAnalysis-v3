from chains.data_extractor import extract_data
from chains.financial_analysis import analyze_financials
from chains.sentiment_analysis import run_sentiment_analysis
from chains.peer_benchmarking import benchmark_peers

def run(symbol: str):
    print(f"📥 Extracting data for {symbol}...")
    data = extract_data(symbol)

    print("📊 Running financial analysis...")
    ratios = analyze_financials(data['yf_data'])

    print("📰 Running sentiment analysis...")
    sentiment = run_sentiment_analysis(symbol)

    print("👥 Running peer benchmarking...")
    peers = benchmark_peers(symbol)

    return {
        "financials": ratios,
        "10k_summary": data["10k_summary"],
        "sentiment": sentiment,
        "peers": peers
    }

if __name__ == "__main__":
    results = run("AAPL")
    print(results)